import pytest
import os
import sys
from fastapi.testclient import TestClient

sys.path.insert(0, "/data/agentic_os")

from server.os_server import app, registry, engine, swarm_orchestrator, workflow_engine
from kernel.execution_engine import ExecutionTaskRequest
from kernel.swarm_orchestrator import SwarmPipelineRequest


@pytest.fixture
def client():
    return TestClient(app)


def test_registry_loaded_268_agents():
    stats = registry.get_stats()
    assert stats["total_agents"] >= 250
    assert stats["total_departments"] >= 15


def test_execution_engine_single_agent():
    agent_id = list(registry.agents.keys())[0]
    req = ExecutionTaskRequest(
        agent_id=agent_id,
        task_prompt="Design a software architecture specification for scalable API microservices."
    )
    result = engine.run_agent_task(req)
    assert result.status == "COMPLETED"


def test_workflow_engine_execution():
    workflows = workflow_engine.list_workflows()
    assert len(workflows) >= 3

    wf_id = workflows[0]["id"]
    res = workflow_engine.execute_workflow(wf_id, "Build automated AI customer support agent")
    assert res.status == "COMPLETED"
    assert len(res.executed_steps) >= 3


def test_fastapi_workflow_endpoints(client):
    wf_res = client.get("/api/workflows/list")
    assert wf_res.status_code == 200
    assert len(wf_res.json()) >= 3

    run_res = client.post("/api/workflows/execute", json={
        "workflow_id": wf_res.json()[0]["id"],
        "input_goal": "Optimize e-commerce logistics and fulfillment pipeline"
    })
    assert run_res.status_code == 200
    assert run_res.json()["status"] == "COMPLETED"
