import os
import sys
import time
from typing import Dict, Any, List, Optional
from fastapi import FastAPI, HTTPException, Query
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel

# Add root directory to sys.path
sys.path.insert(0, "/data/agentic_os")

from kernel.agent_loader import AgentRegistry
from kernel.execution_engine import ExecutionEngine, ExecutionTaskRequest
from kernel.swarm_orchestrator import SwarmOrchestrator, SwarmPipelineRequest
from kernel.workflow_engine import WorkflowEngine, WorkflowExecutionResult

app = FastAPI(
    title="Hermes Agentic OS Kernel & Control Platform",
    description="Autonomous OS Platform for 268+ specialized AI Agents and Swarm Orchestration.",
    version="1.0.0"
)

# Initialize Kernel Systems
registry = AgentRegistry(repo_path="/data/agency-agents-zh")
engine = ExecutionEngine(registry)
swarm_orchestrator = SwarmOrchestrator(registry, engine)
workflow_engine = WorkflowEngine(registry, engine)

STATIC_DIR = "/data/agentic_os/ui/static"
os.makedirs(STATIC_DIR, exist_ok=True)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/", response_class=HTMLResponse)
def serve_os_dashboard():
    index_path = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return HTMLResponse("<h1>Agentic OS Initializing...</h1>")


# =====================================================================
# AGENT REGISTRY APIS
# =====================================================================

@app.get("/api/agents/stats")
def get_registry_stats():
    return registry.get_stats()


@app.get("/api/agents/list")
def list_agents(department: Optional[str] = None, q: Optional[str] = None):
    return registry.list_agents(department=department, search_query=q)


@app.get("/api/agents/{agent_id}")
def get_agent_detail(agent_id: str):
    agent = registry.get_agent(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found in registry")
    return agent.model_dump()


# =====================================================================
# EXECUTION ENGINE APIS
# =====================================================================

@app.post("/api/execution/run")
def run_agent_task(payload: ExecutionTaskRequest):
    return engine.run_agent_task(payload)


@app.get("/api/execution/history")
def get_execution_history(limit: int = 50):
    return engine.get_history(limit=limit)


# =====================================================================
# WORKFLOW ENGINE APIS
# =====================================================================

@app.get("/api/workflows/list")
def list_workflows():
    return workflow_engine.list_workflows()


class WorkflowRunInput(BaseModel):
    workflow_id: str
    input_goal: str


@app.post("/api/workflows/execute")
def execute_workflow(payload: WorkflowRunInput):
    return workflow_engine.execute_workflow(payload.workflow_id, payload.input_goal)


@app.get("/api/workflows/history")
def get_workflow_history():
    return workflow_engine.get_execution_history()


# =====================================================================
# SWARM ORCHESTRATOR APIS
# =====================================================================

@app.post("/api/swarm/execute")
def execute_swarm_pipeline(payload: SwarmPipelineRequest):
    return swarm_orchestrator.execute_swarm(payload)


@app.get("/api/swarm/history")
def get_swarm_history():
    return swarm_orchestrator.get_swarm_history()


# =====================================================================
# OS TELEMETRY & HEALTH API
# =====================================================================

@app.get("/api/os/telemetry")
def get_os_telemetry():
    stats = registry.get_stats()
    return {
        "status": "ONLINE",
        "system": "Agentic OS Kernel 1.0",
        "uptime_sec": round(time.time(), 1),
        "total_loaded_agents": stats["total_agents"],
        "total_departments": stats["total_departments"],
        "executed_tasks_count": len(engine.execution_history),
        "executed_workflows_count": len(workflow_engine.execution_history),
        "executed_swarms_count": len(swarm_orchestrator.swarm_history)
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
