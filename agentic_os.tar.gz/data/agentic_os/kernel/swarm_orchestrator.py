import time
from datetime import datetime
from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field

from kernel.agent_loader import AgentRegistry
from kernel.execution_engine import ExecutionEngine, ExecutionTaskRequest


class SwarmPipelineRequest(BaseModel):
    title: str
    goal_description: str
    agent_sequence: List[str]  # List of agent_ids in order of pipeline execution
    initial_context: Optional[Dict[str, Any]] = Field(default_factory=dict)


class SwarmStepResult(BaseModel):
    step_number: int
    agent_id: str
    agent_name: str
    input_prompt: str
    output_deliverable: str
    execution_time_sec: float


class SwarmPipelineResult(BaseModel):
    swarm_id: str
    title: str
    status: str  # COMPLETED, FAILED
    total_steps: int
    step_results: List[SwarmStepResult]
    final_aggregated_output: str
    total_time_sec: float
    created_at: str


class SwarmOrchestrator:
    """
    Multi-Agent Swarm Orchestration Engine.
    Executes sequential or DAG multi-agent workflows with state handoffs between agents.
    """

    def __init__(self, registry: AgentRegistry, engine: ExecutionEngine):
        self.registry = registry
        self.engine = engine
        self.swarm_history: List[SwarmPipelineResult] = []

    def execute_swarm(self, req: SwarmPipelineRequest) -> SwarmPipelineResult:
        start_time = time.time()
        swarm_id = f"swarm_{int(time.time() * 1000)}"

        step_results: List[SwarmStepResult] = []
        accumulated_context = req.goal_description

        for idx, agent_id in enumerate(req.agent_sequence, start=1):
            step_start = time.time()
            spec = self.registry.get_agent(agent_id)
            agent_name = spec.name if spec else agent_id

            # Craft prompt passing previous step context to the next agent
            step_prompt = (
                f"Step {idx} in Swarm '{req.title}'.\n"
                f"Global Goal: {req.goal_description}\n"
                f"Context from Previous Agents:\n{accumulated_context}\n\n"
                f"As {agent_name}, produce your domain deliverable."
            )

            task_req = ExecutionTaskRequest(
                agent_id=agent_id,
                task_prompt=step_prompt,
                enable_tools=True
            )

            exec_res = self.engine.run_agent_task(task_req)

            step_res = SwarmStepResult(
                step_number=idx,
                agent_id=agent_id,
                agent_name=agent_name,
                input_prompt=step_prompt,
                output_deliverable=exec_res.output_response,
                execution_time_sec=round(time.time() - step_start, 3)
            )

            step_results.append(step_res)
            # Hand off output to next agent in chain
            accumulated_context += f"\n\n--- [Output from {agent_name}] ---\n" + exec_res.output_response

        total_time = round(time.time() - start_time, 3)

        final_result = SwarmPipelineResult(
            swarm_id=swarm_id,
            title=req.title,
            status="COMPLETED",
            total_steps=len(step_results),
            step_results=step_results,
            final_aggregated_output=accumulated_context,
            total_time_sec=total_time,
            created_at=datetime.now().isoformat()
        )

        self.swarm_history.append(final_result)
        return final_result

    def get_swarm_history(self) -> List[Dict[str, Any]]:
        return [s.model_dump() for s in reversed(self.swarm_history)]
