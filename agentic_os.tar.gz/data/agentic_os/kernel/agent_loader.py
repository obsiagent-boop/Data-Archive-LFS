import os
import re
import glob
from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field


class AgentSpec(BaseModel):
    id: str
    name: str
    department: str
    file_path: str
    description: str
    system_prompt: str
    tools_required: List[str] = Field(default_factory=list)
    capabilities: List[str] = Field(default_factory=list)


class AgentRegistry:
    """
    Parses, indexes, and manages all 268 specialized AI agent specs from agency-agents-zh.
    """

    def __init__(self, repo_path: str = "/data/agency-agents-zh"):
        self.repo_path = repo_path
        self.agents: Dict[str, AgentSpec] = {}
        self.departments: Dict[str, List[str]] = {}
        self._load_all_agents()

    def _extract_metadata(self, content: str, file_path: str, dept: str) -> AgentSpec:
        filename = os.path.basename(file_path).replace(".md", "")
        
        # Extract title/name
        title_match = re.search(r"^#\s+(.+)$", content, re.MULTILINE)
        name = title_match.group(1).strip() if title_match else filename.replace("-", " ").title()

        # Extract description / identity
        desc_match = re.search(r"(?:角色描述|身份|Description|Role)[:：]?\s*(.+)", content, re.IGNORECASE)
        if not desc_match:
            desc_match = re.search(r"##\s+(?:概述|简介|角色|Overview)\s*\n+(.+)", content, re.IGNORECASE)
        description = desc_match.group(1).strip() if desc_match else f"{name} specialized agent for {dept}."

        # Extract capabilities
        caps = re.findall(r"[-*]\s+(.+)", content[:2000])
        capabilities = [c.strip() for c in caps if len(c) < 100][:5]

        # Extract tools
        tools = []
        if any(w in content.lower() for w in ["code", "python", "script", "terminal"]):
            tools.append("terminal")
        if any(w in content.lower() for w in ["web", "search", "google", "browser"]):
            tools.append("web_search")
        if any(w in content.lower() for w in ["file", "document", "read", "write"]):
            tools.append("file_io")

        return AgentSpec(
            id=filename,
            name=name,
            department=dept,
            file_path=file_path,
            description=description[:250],
            system_prompt=content,
            tools_required=tools,
            capabilities=capabilities
        )

    def _load_all_agents(self):
        if not os.path.exists(self.repo_path):
            return

        pattern = os.path.join(self.repo_path, "**", "*.md")
        md_files = glob.glob(pattern, recursive=True)

        for filepath in md_files:
            rel_path = os.path.relpath(filepath, self.repo_path)
            parts = rel_path.split(os.sep)

            # Skip root docs
            if len(parts) < 2 or parts[0] in [".git", "assets", "scripts"]:
                continue

            dept = parts[0]
            if not os.path.isfile(filepath):
                continue

            try:
                with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()

                spec = self._extract_metadata(content, filepath, dept)
                self.agents[spec.id] = spec

                if dept not in self.departments:
                    self.departments[dept] = []
                self.departments[dept].append(spec.id)
            except Exception as e:
                pass

    def get_agent(self, agent_id: str) -> Optional[AgentSpec]:
        return self.agents.get(agent_id)

    def list_agents(self, department: Optional[str] = None, search_query: Optional[str] = None) -> List[Dict[str, Any]]:
        results = []
        for agent in self.agents.values():
            if department and agent.department.lower() != department.lower():
                continue
            if search_query:
                q = search_query.lower()
                if q not in agent.name.lower() and q not in agent.description.lower() and q not in agent.id.lower():
                    continue
            results.append({
                "id": agent.id,
                "name": agent.name,
                "department": agent.department,
                "description": agent.description,
                "tools_required": agent.tools_required,
                "capabilities": agent.capabilities
            })
        return results

    def get_stats(self) -> Dict[str, Any]:
        return {
            "total_agents": len(self.agents),
            "total_departments": len(self.departments),
            "departments_list": list(self.departments.keys())
        }
