import time
from datetime import datetime
from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field

from kernel.agent_loader import AgentRegistry
from kernel.execution_engine import ExecutionEngine, ExecutionTaskRequest


class WorkflowStep(BaseModel):
    step_number: int
    name: str
    agent_id: str
    instruction_template: str


class WorkflowDefinition(BaseModel):
    id: str
    title: str
    category: str
    description: str
    steps: List[WorkflowStep]


class ExecutedWorkflowStep(BaseModel):
    step_number: int
    step_name: str
    agent_id: str
    agent_name: str
    status: str
    prompt_used: str
    output_result: str
    duration_sec: float


class WorkflowExecutionResult(BaseModel):
    execution_id: str
    workflow_id: str
    workflow_title: str
    status: str  # COMPLETED, FAILED
    executed_steps: List[ExecutedWorkflowStep]
    final_deliverable_summary: str
    total_duration_sec: float
    timestamp: str


class WorkflowEngine:
    """
    Engine for executing and managing complex multi-agent workflows.
    """

    def __init__(self, registry: AgentRegistry, engine: ExecutionEngine):
        self.registry = registry
        self.engine = engine
        self.workflows: Dict[str, WorkflowDefinition] = {}
        self.execution_history: List[WorkflowExecutionResult] = []
        self._load_default_workflows()

    def _load_default_workflows(self):
        wf1 = WorkflowDefinition(
            id="wf_fullstack_sdlc",
            title="Full-Stack Product & Software Engineering SDLC",
            category="Engineering & Product",
            description="End-to-end product development lifecycle: PRD creation -> System Architecture -> Code Implementation -> QA Testing.",
            steps=[
                WorkflowStep(step_number=1, name="PRD & Requirements Drafting", agent_id="product-product-manager", instruction_template="Draft a structured PRD for: {input_goal}"),
                WorkflowStep(step_number=2, name="System Architecture Design", agent_id="engineering-software-architect", instruction_template="Based on the PRD, create system architecture, DB schema, and API contracts."),
                WorkflowStep(step_number=3, name="Backend & Frontend Implementation", agent_id="engineering-backend-developer", instruction_template="Write production-ready code implementation based on the architecture specification."),
                WorkflowStep(step_number=4, name="QA Testing & Verification", agent_id="testing-embedded-qa-engineer", instruction_template="Run security scans, unit tests, and generate QA verification report.")
            ]
        )

        wf2 = WorkflowDefinition(
            id="wf_growth_marketing",
            title="Growth Marketing & Multichannel Campaign Engine",
            category="Marketing & Sales",
            description="Automated marketing campaign strategy, copy generation, and platform optimization (Red/Douyin).",
            steps=[
                WorkflowStep(step_number=1, name="Market Strategy & Audience Research", agent_id="marketing-growth-hacker", instruction_template="Develop growth strategy and target persona positioning for: {input_goal}"),
                WorkflowStep(step_number=2, name="Copywriting & Ad Content Generation", agent_id="marketing-copywriter", instruction_template="Draft compelling marketing copy, email headlines, and CTA offers."),
                WorkflowStep(step_number=3, name="Platform Optimization (Red/Douyin)", agent_id="marketing-xiaohongshu-specialist", instruction_template="Format content into viral hooks and visual post structures.")
            ]
        )

        wf3 = WorkflowDefinition(
            id="wf_incident_security",
            title="Enterprise Incident Response & Security Hardening",
            category="Security & Operations",
            description="Vulnerability assessment, threat mitigation playbook, and patch verification.",
            steps=[
                WorkflowStep(step_number=1, name="Security Audit & Vulnerability Scan", agent_id="security-pentester", instruction_template="Perform threat assessment and vulnerability audit for: {input_goal}"),
                WorkflowStep(step_number=2, name="Incident Response Playbook", agent_id="security-incident-responder", instruction_template="Formulate containment steps and security remediation strategy."),
                WorkflowStep(step_number=3, name="Infrastructure Patch Verification", agent_id="support-infrastructure-maintainer", instruction_template="Apply system hardening patches and verify operational health.")
            ]
        )

        self.workflows[wf1.id] = wf1
        self.workflows[wf2.id] = wf2
        self.workflows[wf3.id] = wf3

    def list_workflows(self) -> List[Dict[str, Any]]:
        return [wf.model_dump() for wf in self.workflows.values()]

    def execute_workflow(self, workflow_id: str, input_goal: str) -> WorkflowExecutionResult:
        start_time = time.time()
        exec_id = f"wf_exec_{int(time.time() * 1000)}"

        wf_def = self.workflows.get(workflow_id)
        if not wf_def:
            # Fallback to general workflow
            wf_def = list(self.workflows.values())[0]

        executed_steps: List[ExecutedWorkflowStep] = []
        accumulated_output = f"Goal: {input_goal}\n"

        for step in wf_def.steps:
            step_start = time.time()
            prompt = step.instruction_template.replace("{input_goal}", input_goal) + f"\n\nPrior Context:\n{accumulated_output}"
            
            # Find closest agent or fallback
            spec = self.registry.get_agent(step.agent_id)
            if not spec:
                # Find any agent in registry
                spec = list(self.registry.agents.values())[0]

            task_req = ExecutionTaskRequest(agent_id=spec.id, task_prompt=prompt, enable_tools=True)
            exec_res = self.engine.run_agent_task(task_req)

            step_exec = ExecutedWorkflowStep(
                step_number=step.step_number,
                step_name=step.name,
                agent_id=spec.id,
                agent_name=spec.name,
                status="COMPLETED",
                prompt_used=prompt,
                output_result=exec_res.output_response,
                duration_sec=round(time.time() - step_start, 3)
            )

            executed_steps.append(step_exec)
            accumulated_output += f"\n\n--- [{step.name} by {spec.name}] ---\n" + exec_res.output_response

        total_time = round(time.time() - start_time, 3)

        res = WorkflowExecutionResult(
            execution_id=exec_id,
            workflow_id=wf_def.id,
            workflow_title=wf_def.title,
            status="COMPLETED",
            executed_steps=executed_steps,
            final_deliverable_summary=accumulated_output,
            total_duration_sec=total_time,
            timestamp=datetime.now().isoformat()
        )

        self.execution_history.append(res)
        return res

    def get_execution_history(self) -> List[Dict[str, Any]]:
        return [e.model_dump() for e in reversed(self.execution_history)]
