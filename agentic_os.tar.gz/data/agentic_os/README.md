# 🖥️ Hermes Agentic OS Platform

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110+-009688.svg)](https://fastapi.tiangolo.com)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Agents Loaded: 292](https://img.shields.io/badge/Agents-292%20Loaded-brightgreen.svg)]()

Autonomous Operating System Platform designed to load, index, execute, and orchestrate all **268+ specialized AI Agents** from `agency-agents-zh` across 22 departments.

---

## ⚡ Core Features

1. **Agent Kernel & Registry Engine:** Automatically indexes and parses system prompts, role specifications, and capability tools from 268+ markdown role definitions.
2. **Execution Studio & Sandbox:** Runs individual agent tasks with sandboxed local tool execution (terminal, file system, code runner).
3. **Multi-Agent Swarm Orchestrator:** Chained pipeline executor supporting sequential agent handoffs, context propagation, and result synthesis.
4. **Desktop & Web Dashboard UI:** Futuristic dark-mode interface for searching agents, inspecting system prompts, triggering swarm workflows, and viewing execution telemetry.

---

## 🚀 Deployment Instructions

### Option 1: Docker Compose (Deploy Anywhere in 1 Click)

```bash
# Clone or copy repo
cd agentic_os

# Build & launch detached container
docker compose up -d --build
```

Access dashboard at **`http://localhost:8080`**.

### Option 2: Standalone Python Deployment

```bash
# Install dependencies
pip install fastapi uvicorn pydantic pytest

# Launch Agentic OS Kernel Server
python3 server/os_server.py
```

### Option 3: Run Unit Tests
```bash
pytest tests/test_os_kernel.py -v
```

---

## 📡 Key REST APIs

* `GET /api/os/telemetry` — OS System status & aggregate stats
* `GET /api/agents/list` — List & search 268+ agents across 22 departments
* `GET /api/agents/{id}` — Get agent system prompt & details
* `POST /api/execution/run` — Run task on specific agent
* `POST /api/swarm/execute` — Execute multi-agent swarm pipeline

---

## 📄 License
MIT License.
